<?php
/*
Template Name: Gallery
*/

get_header(); // Inclure l'en-tête de thème

// Inclure le contenu de ton fichier categories.php
include get_template_directory() . '/categories.php';

get_footer(); // Inclure le pied de page de thème